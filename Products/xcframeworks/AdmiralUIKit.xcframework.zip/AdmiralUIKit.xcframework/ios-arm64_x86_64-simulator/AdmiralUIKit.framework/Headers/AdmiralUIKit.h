//
//  AdmiralUIKit.h
//  AdmiralUIKit
//
//  Created on 16.03.2021.
//

#import <Foundation/Foundation.h>

//! Project version number for AdmiralUIKit.
FOUNDATION_EXPORT double AdmiralUIKitVersionNumber;

//! Project version string for AdmiralUIKit.
FOUNDATION_EXPORT const unsigned char AdmiralUIKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AdmiralUIKit/PublicHeader.h>


