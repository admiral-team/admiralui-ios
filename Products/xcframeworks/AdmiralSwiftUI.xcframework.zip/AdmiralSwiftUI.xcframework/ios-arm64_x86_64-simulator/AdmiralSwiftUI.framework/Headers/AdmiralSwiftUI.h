//
//  AdmiralSwiftUI.h
//  AdmiralSwiftUI
//
//  Created on 15.03.2021.
//

#import <Foundation/Foundation.h>

//! Project version number for AdmiralSwiftUI.
FOUNDATION_EXPORT double AdmiralSwiftUIVersionNumber;

//! Project version string for AdmiralSwiftUI.
FOUNDATION_EXPORT const unsigned char AdmiralSwiftUIVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AdmiralSwiftUI/PublicHeader.h>


