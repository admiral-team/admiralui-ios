//
//  AdmiralTheme.h
//  AdmiralTheme
//
//  Created on 12.03.2021.
//

#import <Foundation/Foundation.h>

//! Project version number for AdmiralTheme.
FOUNDATION_EXPORT double AdmiralThemeVersionNumber;

//! Project version string for AdmiralTheme.
FOUNDATION_EXPORT const unsigned char AdmiralThemeVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AdmiralTheme/PublicHeader.h>


