//
//  AdmiralUIResources.h
//  AdmiralUIResources
//
//  Created on 15.03.2021.
//

#import <Foundation/Foundation.h>

//! Project version number for AdmiralUIResources.
FOUNDATION_EXPORT double AdmiralUIResourcesVersionNumber;

//! Project version string for AdmiralUIResources.
FOUNDATION_EXPORT const unsigned char AdmiralUIResourcesVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AdmiralUIResources/PublicHeader.h>


